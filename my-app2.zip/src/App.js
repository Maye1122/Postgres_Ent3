import './App.css';
// import './responsive.css';
// import './seccionPlantas.css';

import {BrowserRouter,Routes, Route, Link} from "react-router-dom";

import { Creando } from './components/Creando';
import NotFound from './components/NotFound';
import Homepage from './components/Homepage';



function App() {
  return(
<>
		  <Routes>
		  <Route path="/creando" element={<Creando/>}/>
		  <Route path="/" element={<Homepage/>}/>
		  <Route path="*" element={<NotFound/>}/>
		  
	  </Routes>

</>


	

  )
}


export default App;


 /* <Routes>
        <Route to="/flores/:id" ></Route>
      </Routes> */