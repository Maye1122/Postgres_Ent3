import { Link } from "react-router-dom";
import Login from './Login';
import CartButton from "./CartButton";
import LoginButton from "./LoginButton";

export function Header() {
	return(
		<header className="header">
		<Link to="/"><img src="/images/poto5.jpg" alt="logo"/></Link>
		<h1>
		  "Siempre hay flores para el que desea verlas" <br />
		  <cite>Henri Matisse</cite>
		</h1>
  <LoginButton/>
  <Login/>
  <CartButton/>
	  </header>
	)
}