const CartButton = () =>{
	return (
		<button className="carrito" >
		  <i className="fas fa-shopping-cart"></i
		  ><span className="shopping-cart">&nbsp; Carrito</span> &nbsp;
		</button>
	)
}

export default CartButton;

 <a href="#">
			<i className="fas fa-shopping-cart"></i>
		    <span className="indicacion">Carrito</span> 
		</a> 