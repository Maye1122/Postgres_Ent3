import {Navbar2} from './Navbar2';
import Footer from './Footer';
import Galeria2 from './Galeria2';
import { Header } from './Header';




function Homepage() {
  return(
	<>
		<Header/>
		<Navbar2/>
		<Galeria2 />
		<Footer />
	</>
  )
}


export default Homepage;

