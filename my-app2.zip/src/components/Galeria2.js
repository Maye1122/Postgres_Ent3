
function Galeria2() {
	return(
		<section className="section">
		<div className="contenedorImg">
		  <div className="imagen">
			<img
			  src="/images/redFlower.jpg"
			  alt="Amapola de campo"
			  className="imagen1"
			/>
			<div className="overlay">
			  <p>Papaver rhoeas</p>
			</div>
		  </div>
		  <div className="imagen">
			<img src="/images/tulipan.jpg" alt="tulipan" className="imagen2" />
			<div className="overlay"><p>Tulipanes</p></div>
		  </div>
		  <div className="imagen">
			<img src="/images/potted.jpg" alt="Ficus" className="imagen3" />
			<div className="overlay"><p>Ficus Lyrata</p></div>
		  </div>
  
		  <div className="imagen">
			<img src="/images/cactus.jpg" alt="Cactus" className="imagen4" />
			<div className="overlay"><p>Cactus</p></div>
		  </div>
		  <div className="imagen">
			<img src="/images/gladiolus.jpg" alt="gladiolus" className="imagen5" />
			<div className="overlay"><p>Gladiolos</p></div>
		  </div>
		  <div className="imagen">
			<img src="/images/daisy.jpg" alt="Daisy Flower" className="imagen6" />
			<div className="overlay"><p>Margaritas</p></div>
		  </div>
		</div>
	  </section>
	)
	
}

export default Galeria2;