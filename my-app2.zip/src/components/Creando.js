import { Link } from "react-router-dom";
//import background from "/images/redFlower.jpg";


export function Creando() {
	return(
		
		<Link to={"/"}>
			 
			 <section style={{ backgroundImage: "url(/images/Creando.jpg)",
  width:'100%', height: '100%'}}>
			  <p style={{fontSize:'2rem', color:"white"}}>
				  Pagina en proceso... Volver a pagina de inicio</p>
				 </section>
				
				 
			
			 
			
		</Link>
	)
}

export default Creando;