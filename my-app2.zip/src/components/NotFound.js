
const NotFound = () => {
    return <>
        <h1>404</h1>
        <main>
            Error 404 Pagina no encontrada
        </main>
    </>
}

export default NotFound