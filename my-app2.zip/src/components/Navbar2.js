import { Link } from "react-router-dom"
import Creando from "./Creando";
import { Routes, Route } from "react-router";


export function Navbar2() {

    return (
    <nav>
		<div className="topnav" id="myTopnav">
		<div className="dropdown">
                <button className="dropbtn">
                  Plantas
                  <i className="fa fa-caret-down"></i>
                </button>
                <div className="dropdown-content" id="navContent">
                  <Link to="/plantas">Flores de estación</Link>
                  <Link to="/creando"><p>Plantas de colección</p></Link>
                  <Link to="/cactus"><p>Cactus</p></Link>
                </div>
              </div>

			  <div className="dropdown">
                <button className="dropbtn">
                  Accesorios
                  <i className="fa fa-caret-down"></i>
                </button>
                <div className="dropdown-content">
                  <Link to="/Creando">Guantes</Link>
                  <Link to="/Creando"><p>Tijeras</p></Link>
                </div>

				
              </div>

			  <div className="dropdown">
                <button className="dropbtn">
                  Promociones
                  <i className="fa fa-caret-down"></i>
                </button>
                <div className="dropdown-content">
				<Link to="./creando"><p>Planta del mes</p></Link>
                </div>
              </div>

			  <div className="dropdown">
                <button className="dropbtn">
                  Información
                  <i className="fa fa-caret-down"></i>
                </button>
                <div className="dropdown-content">
                  <Link to="./creando"><p>Equipo</p></Link>
				  <Link to={"./creando"}><p>Contactenos</p></Link>
				  <Link to={"./creando"}><p>Horarios</p></Link>
                </div>
              </div>
		</div>
	</nav>
	
    )
}
 

export default Navbar2;