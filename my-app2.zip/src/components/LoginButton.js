const  LoginButton = () =>{
	return (
		<button onClick={()=>document.getElementById('id01').style.display='block'}>
		  <i className="fas fa-user"></i
		  ><span className="usuario">&nbsp; Login</span> &nbsp;
		</button>
		)
}

export default LoginButton;