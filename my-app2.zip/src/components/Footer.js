

function Footer () {
    return (
        <footer>
      <div className="contenedor">
        <div className="column1">
          <h3>Nuestra empresa</h3>
          <p>
            Ofrecemos las plantas mas hermosas para decorar tus lugares
            favoritos, tanto interiores como exteriores.
          </p>
        </div>
        <div className="column2">
          <h3>Siguenos en RRSS</h3>
          <div>
            <i className="fab fa-facebook"></i>&nbsp;&nbsp;<a href="./Creando"
              >Siguenos en Facebook</a
            >
          </div>
          <div>
            <i className="fab fa-pinterest"></i>&nbsp;&nbsp;<a href="./Creando.html"
              >Siguenos en Pinterest</a
            >
          </div>
          <div>
            <i className="fab fa-instagram"></i>&nbsp;&nbsp;<a href="./Creando.html"
              >Siguenos en Instagram</a
            >
          </div>
        </div>
        <div className="column3">
          <h3>Contactanos</h3>
          <div>
            <i className="far fa-envelope"></i
            ><a href="./Creando.html">Escribenos</a>
          </div>
          <div>
            <i className="fas fa-map-marker-alt"></i
            ><label>Av. Italia 535 Montevideo, Uruguay</label>
          </div>
          <div>
            <i className="fas fa-mobile-alt"></i><label>+598 99 222 222</label>
          </div>
        </div>
      </div>
    </footer>

    )
}

export default Footer;