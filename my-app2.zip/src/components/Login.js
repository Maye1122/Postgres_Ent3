export default function Login () {
	return (
		<div className="logo">
		<div id="id01" className="modal">
		  <form
			className="modal-content animate"
			action={"/Creando"}
			method="post"
		  >
			<div className="imgcontainer">
			  <span
				onClick={ ()=>document.getElementById('id01').style.display='none'}
				className="close"
				title="Close Modal"
				>&times;</span>
			</div>

			<div className="container">
			  <label for="uname"><b>Nombre usuario</b></label>
			  <input
				type="text"
				id="nombreDeUsuario"
				placeholder="Ingrese el nombre de usuario"
				name="uname"
				required
			  />

		  

			  <label for="uname"><b>Email</b></label>
			  <input
				type="text" id="email"
				placeholder="Ingrese su email"
				name="uname"
				required
			  />

			  <label for="psw"><b>Contraseña</b></label>
			  <input
				type="password" id="password"
				placeholder="Ingrese su Contraseña"
				name="psw"
				required
			  />

			  <button type="submit" id="botonRegistro" className="botonRegistro" style={{"backgroundcolor": "rgb(177, 240, 240)"}}>Registro</button>
			  
			</div>

			<div className="container" style={{"background-color": "#f1f1f1"}}>
			  <button
				type="button"
				onclick="document.getElementById('id01').style.display='none'"
				className="cancelbtn"
			  >
				Cancel
			  </button>
			  <span className="psw">Forgot <a href="#">password?</a></span>
			</div>
		  </form>
		</div> 		
	  </div>
	)
}
