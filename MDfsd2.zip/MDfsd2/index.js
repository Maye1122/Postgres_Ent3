const express = require("express");
const auth = require("./auth");
const path = require("path");


const {Client} = require('pg');
const {resolve} = require('path');
const {config} = require('dotenv');
const { text, response } = require("express");
config ({path: resolve(__dirname,"./.env")});

const app = express();
const PORT = 8000;  

app.use(express.json());
app.use(
    express.urlencoded({
      extended: true,
    })
  );

app.use(express.static(path.join(__dirname, "./PrSenpai/index")));
app.use(auth);


app.use(express.json());
app.listen(PORT, function () {
    console.log(`El servidor quedo corriendo en el puerto ${PORT}`);
  });


  app.get('test',async(req,res,next)=>{
	  try {
		  const Client = new Client();
		  client.connect();

		  client.query("select $1:: text as message",["hola mundo"],(err,res)=>{
			  if (err) {
				  console.error(err.stack);
			  } else {
				  console.log(res.rows[0].message);
				  response.send(res.rows[0].message);
			  }
			  client.end();
		  });
	  } catch (error) {
		  return next(error);
	  }
  })