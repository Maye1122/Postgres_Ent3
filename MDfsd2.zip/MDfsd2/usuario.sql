create table login(
nombre varchar (60) not null,
email varchar (100) not null,
contrase�a VARCHAR(20) not null

);

insert into login ( nombre, email, contrase�a) values ('Maira D','mairad@gmail.com', 123), ('Luis Perez', 'luis.perez@gmail.com', 321),
('Yenny Salvo', 'ysalvo@gmail.com',345);


select * from login 


CREATE TABLE departamentos ( dep int NOT NULL,
departamento varchar(255),
PRIMARY KEY (dep)
);



CREATE TABLE personas
(per int NOT NULL,
nombre varchar(255),
apellido1 varchar(255),
dep int NOT NULL,
PRIMARY KEY (per),
FOREIGN KEY (dep) REFERENCES departamentos(dep)
);

create table ejemplo3 (
email varchar (100) not null,
pais varchar (40),
ciudad varchar (40),
primary key (email)
);


select  *from pais

insert into pais values ('mairad@gmail.com', 'Uruguay', 'Montevideo');

insert into pais values ('luis.perez@gmail.com', 'Paraguay', 'Asuncion'),('ysalvo@gmail.com','Colombia','Bogota');

select  * from pais

select * from login inner join pais on login.email = pais.email;


insert into otrosdatos values ('mairad@gmail.com', 'Uruguay', 'Montevideo');

insert into otrosdatos values ('luis.perez@gmail.com', 'Paraguay', 'Asuncion'),('ysalvo@gmail.com','Colombia','Bogota');
